URL as Input/Output
===================

This is a sample project to test use of URL as an output and input for shiny scripts.

It presents the data in 3 ways:

 * in the URL
 * in the Input controls
 * as text in the output
 
You can copy and share the URL
You can edit the URL (and press enter) to update.
The URL is live updated.
It only works on browsers which support hashchange - so probably webkit & FF.

Goals
=====

The goal is to use the URL as a _duplicate_ of the input state of a shiny app, with the following features:

    * URL gets updated as input gets updated
    * input gets updated as URL gets updated
    * some mechanism to avoid circuits
    * If URL is provided to a new browser, page state is reproduced


Technology Warning
==================

Initially it will use the 'hashchange' event, which is NOT universally available.

There is an option to use various query.js plugins later.

Also I haven't thought carefully about feedback loops - it might explode in flames.

Version Log
===========

* Fields to sync is now a variable - not hardcoded in the server
* Supports textinput fields as well (included in example)